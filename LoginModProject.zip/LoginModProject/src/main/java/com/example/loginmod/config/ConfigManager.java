package com.example.loginmod.config;

public class ConfigManager {
    public static String getDefaultPassword() {
        return "123456";
    }
}