package com.example.loginmod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class LoginMod implements ModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("loginmod");
    public static final Set<UUID> LOGGED_IN_PLAYERS = new HashSet<>();

    @Override
    public void onInitialize() {
        LOGGER.info("中文登录模组已加载");
        
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            LoginCommand.register(dispatcher);
        });
        
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> 
            LoginCallback.onPlayerJoin(handler.getPlayer())
        );
    }
}