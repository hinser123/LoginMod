package com.example.loginmod;

import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

public class LoginCallback {
    public static void onPlayerJoin(ServerPlayerEntity player) {
        player.getAbilities().invulnerable = true;
        player.getAbilities().allowFlying = false;
        player.sendAbilitiesUpdate();
        player.sendMessage(Text.literal("§e🔐 请输入 §6/login 密码 §e来解锁游戏"), false);
        player.sendMessage(Text.literal("§7（默认密码：123456）"), false);
    }
}