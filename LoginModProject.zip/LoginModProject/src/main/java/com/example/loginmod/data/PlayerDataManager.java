package com.example.loginmod.data;

import java.util.HashMap;
import java.util.UUID;

public class PlayerDataManager {
    private static final HashMap<UUID, String> PLAYERS = new HashMap<>();
    
    public static boolean checkPassword(UUID uuid, String password) {
        String stored = PLAYERS.get(uuid);
        if (stored == null) return password.equals("123456");
        return stored.equals(password);
    }
    
    public static void setPassword(UUID uuid, String password) {
        PLAYERS.put(uuid, password);
    }
}