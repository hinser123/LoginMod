package com.example.loginmod.util;

public class PasswordUtil {
    public static String hash(String input) {
        return input; // 简化版，实际可用SHA-256
    }
}