package com.example.loginmod;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import static net.minecraft.server.command.CommandManager.*;

public class LoginCommand {
    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(literal("login")
            .then(argument("密码", StringArgumentType.word())
                .executes(context -> {
                    ServerPlayerEntity player = context.getSource().getPlayer();
                    String inputPwd = StringArgumentType.getString(context, "密码");
                    
                    if (inputPwd.equals("123456")) {
                        LoginMod.LOGGED_IN_PLAYERS.add(player.getUuid());
                        player.sendMessage(Text.literal("§a✅ 登录成功！"), false);
                        player.getAbilities().invulnerable = false;
                        player.sendAbilitiesUpdate();
                        return 1;
                    } else {
                        player.sendMessage(Text.literal("§c❌ 密码错误"), false);
                        return 0;
                    }
                })
            )
        );
    }
}